const mongoose = require("mongoose");
const express = require("express");

//uri connection
const uri =
  "mongodb+srv://krishna:Up2m50s0LrUa5HBh@cluster0.56mab.mongodb.net/";
const dbname = "ecommerce";
const cors=require("cors");
// mongoose status connected to database
mongoose
  .connect(uri, { dbName: dbname })
  .then(() => {
    console.log("mongoDB connected");
  })
  .catch((err) => {
    console.log(err.message);
  });

mongoose.connection.on("connected", () => {
  console.log("mongoose connected to DB");
});

mongoose.connection.on("error", () => {
  console.log(error.message);
});

mongoose.connection.on("disconnected", () => {
  console.log("mongoose connection got disconnected");
});

//initializing express app
const app = express();
app.use(cors())

//initialize sever
app.listen(3000, () => {
  console.log("server listening on port 3000");
});

//importing schema model
const ProductCategory = require("./models");
const SignUp = require("./SignupModel");
const ShopItems = require("./shopProductModel");

//parsing the data when being communicated with express to mongoDB
const bodyParser = require("body-parser");


app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
//adding user to Ecommerce DB

// check qs ,urlencoded,body  in request
app.post("/user", (request, response) => {
  email = request.body.email;
  password = request.body.password;

  //constructor based Schema
  let newSignUp = new SignUp({
    email: email,
    password: password,
  });
  newSignUp
    .save()
    .then((user) => {
      response.send(user);
    })
    .catch((err) => console.log(err));
});

//get call
app.get("/shop", async (req, res) => {
  try {
    const categories = await ProductCategory.find();
    res.json(categories);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

//get call for shop products

app.get("/shop-item", async (req, res) => {
    const shopItems = await ShopItems.find();
    console.log(shopItems);
    res.status(200).send({
      status: "success",
      results: shopItems.length,
      data: {
        shopItems,
      },
    });
  });
//nodejs process for running ot to get exit
process.on("SIGINT", async () => {
  await mongoose.connection.close();
  process.exit(0);
});

//mongoose is interface between nodejs and mongo DB Mongo DB is unstructured
//nodejs completely asynchronous (for machine calculation)
//express for server communication from nodejs (Virtual machine)
